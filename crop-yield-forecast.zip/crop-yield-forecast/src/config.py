"""Central configuration for the yield forecasting project."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "yield_data.csv"
MODEL_PATH = ROOT / "models" / "yield_model.joblib"
METRICS_PATH = ROOT / "models" / "metrics.json"

TARGET = "yield_per_acre"  # quintals per acre

CATEGORICAL = ["district", "crop", "season", "soil_type", "irrigation"]
NUMERIC = [
    "area_acres", "rainfall_mm", "avg_temp_c", "humidity_pct",
    "fertilizer_kg_per_acre", "sowing_month",
]
FEATURES = CATEGORICAL + NUMERIC

RANDOM_STATE = 42
TEST_SIZE = 0.2
