"""Create a synthetic dataset with the same schema as the state agriculture
department field data. Replace data/yield_data.csv with real data when available.

Usage: python -m src.generate_sample_data
"""
import numpy as np
import pandas as pd
from .config import DATA_PATH

def main(n: int = 3000, seed: int = 42) -> None:
    rng = np.random.default_rng(seed)
    crops = {"paddy": 24, "cotton": 9, "maize": 28, "chilli": 14}
    crop = rng.choice(list(crops), n)
    df = pd.DataFrame({
        "district": rng.choice(["Eluru", "Krishna", "Guntur", "West Godavari", "Prakasam"], n),
        "crop": crop,
        "season": rng.choice(["kharif", "rabi"], n),
        "soil_type": rng.choice(["black", "red", "alluvial", "sandy"], n),
        "irrigation": rng.choice(["canal", "borewell", "rainfed"], n),
        "area_acres": rng.uniform(0.5, 15, n).round(2),
        "rainfall_mm": rng.normal(750, 180, n).clip(200, 1400).round(1),
        "avg_temp_c": rng.normal(28, 3, n).round(1),
        "humidity_pct": rng.normal(68, 10, n).clip(30, 95).round(1),
        "fertilizer_kg_per_acre": rng.normal(120, 30, n).clip(30, 250).round(1),
        "sowing_month": rng.integers(1, 13, n),
    })
    base = df["crop"].map(crops)
    irr = df["irrigation"].map({"canal": 1.05, "borewell": 1.0, "rainfed": 0.8})
    y = (base * irr
         + 0.004 * (df["rainfall_mm"] - 750)
         + 0.02 * (df["fertilizer_kg_per_acre"] - 120)
         - 0.25 * (df["avg_temp_c"] - 28).abs()
         + rng.normal(0, 1.5, n))
    df["yield_per_acre"] = y.clip(1).round(2)
    # inject a little mess so preprocessing has work to do
    df.loc[rng.choice(n, 40, replace=False), "rainfall_mm"] = np.nan
    df = pd.concat([df, df.sample(20, random_state=1)], ignore_index=True)
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(DATA_PATH, index=False)
    print(f"Saved {len(df)} rows -> {DATA_PATH}")

if __name__ == "__main__":
    main()
