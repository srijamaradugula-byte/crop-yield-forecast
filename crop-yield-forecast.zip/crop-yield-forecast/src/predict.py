"""Load the trained model and predict yield for one field."""
import joblib
import pandas as pd
from .config import FEATURES, MODEL_PATH

_model = None

def get_model():
    global _model
    if _model is None:
        _model = joblib.load(MODEL_PATH)
    return _model

def predict_yield(record: dict) -> float:
    row = pd.DataFrame([record])[FEATURES]
    for c in ["district", "crop", "season", "soil_type", "irrigation"]:
        row[c] = row[c].astype(str).str.strip().str.lower()
    return float(get_model().predict(row)[0])
